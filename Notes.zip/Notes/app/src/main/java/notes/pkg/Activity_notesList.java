package notes.pkg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

import notes.pkg.adapters.Adapter_recyclerView_notes;
import notes.pkg.models.Note;
import notes.pkg.util.VerticalSpacingItemDecorator;

public class Activity_notesList extends AppCompatActivity {

    private static final String TAG = "Activity_notesList";

    // UI COMPONENTS
    private RecyclerView recyclerView;

    // VARIABLES
    private ArrayList<Note> notes = new ArrayList<>();
    private Adapter_recyclerView_notes notesRecyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        initRecyclerView();
        makeFakeNotes();
    }

    private void initRecyclerView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        VerticalSpacingItemDecorator itemDecorator = new VerticalSpacingItemDecorator(10);
        recyclerView.addItemDecoration(itemDecorator);

        notesRecyclerViewAdapter = new Adapter_recyclerView_notes(notes);
        recyclerView.setAdapter(notesRecyclerViewAdapter);
    }

    private void makeFakeNotes() {
        for (int i=0; i<1000; i++) {
            Note note = new Note("title # " + i, "content # " + i, "jan 2019");
            notes.add(note);
        }

        notesRecyclerViewAdapter.notifyDataSetChanged();
    }
}
